package org.swissre.myserviceb.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("api/b/service")
public class NotificationController {
	
	
	
	@GetMapping("/notify")
	public ResponseEntity<String> getNotification(){
		return ResponseEntity.ok("Service B is received your notification successfully");
	}
	
	
	
	

}
