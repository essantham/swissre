package org.swissre.myservicea.service;


import org.swissre.myservicea.dto.OrderDto;

public interface IOrderService {

	String processOrder(OrderDto orderDto);
	
}
