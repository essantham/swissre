package org.swissre.myservicea.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.swissre.myservicea.dto.OrderDto;
import org.swissre.myservicea.service.IOrderService;


@RestController
@RequestMapping("api/a/service")
public class OrderController {
	
	@Autowired
	IOrderService iOrderService;
	
	@GetMapping("/test")
	public ResponseEntity<String> getMyHealthByPrint(){
		return ResponseEntity.ok("I'm ready to process the request. Please go ahead further!!");
	}
	
	@PostMapping("/order")
    public ResponseEntity<String> processOrder(@RequestBody OrderDto orderDto) {
		return ResponseEntity.ok(iOrderService.processOrder(orderDto));
    }
	
	

}
