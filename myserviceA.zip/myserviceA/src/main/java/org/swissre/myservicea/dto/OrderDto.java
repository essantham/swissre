package org.swissre.myservicea.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OrderDto {
	
	private Long orderId;
	private String orderItem;

}
