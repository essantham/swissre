
package org.swissre.myservicea.service.impl;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;



import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import jakarta.transaction.Transactional;
import org.swissre.myservicea.dto.OrderDto;
import org.swissre.myservicea.entity.OrderStatus;
import org.swissre.myservicea.repo.OrderRepository;
import org.swissre.myservicea.service.IOrderService;

@Service
public class OrderServiceImpl implements IOrderService {

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	OrderRepository orderRepository;

	private static final String	 INPROGRESS = "INPROGRESS";
	private static final String	 SUCCESS = "SUCCESS";
	private static final String	 FAILURE = "FAILURE";
		
	
	@Override
	@Transactional
	@Retry(name = "notificationRetry", fallbackMethod = "notification")
	@CircuitBreaker(name="notificationCircuitBreaker", fallbackMethod = "notification")
	public String processOrder(OrderDto orderDto) {

			Integer orderId = orderStatusUpdate(orderDto,SUCCESS);
			ResponseEntity<String> s = restTemplate.getForEntity("http://localhost:8081/api/b/service/notify", String.class);
			return "Your Order has been Placed, Here is your Order Id : "+orderId + "\n"+s.getBody();
		
	}
wor
	public Integer orderStatusUpdate(OrderDto orderDto,String status){
		OrderStatus orderStatus = OrderStatus.builder().orderItem(orderDto.getOrderItem()).status(status).build();
		return orderRepository.save(orderStatus).getOrderId();
	}


	public String notification(OrderDto orderDto, Throwable throwable) {
		Integer orderId = orderStatusUpdate(orderDto,FAILURE);
        return "Fallback: Service B is currently unavailable and your Order Id is failed"+ orderId;
    }

	
	
}
